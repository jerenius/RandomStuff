$modulespath = ";" + (get-location).tostring() + "modules"
$env:psmodulepath = $env:psmodulepath + $modulespath

.\Get-WindowsAutopilotInfo.ps1 -online