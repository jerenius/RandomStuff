AutopilotOnline.cmd		Ajaa AutopilotOnline.ps1 powershelliss� (ExecutionPolicy Bypass)
AutopilotOnline.ps1		Lis�� USB-levyll� olevat Powershell -moduulit polulle ja ajaa Get-WindowsAutopilot.ps1 -online -optiolla
AutopilotCSV.cmd		Ajaa AutopilotCSV.ps1 powershelliss� (ExecutionPolicy Bypass)
AutopilotCSV.ps1		Ajaa Get-WindowsAutopilot.ps1 ja tekee laitetoista CSV-muotoisen listan
Get-WindowsAutopilotInfo.ps1	Alkuper�inen laitetiedon ker�ysscripti
Modules				Powershellin moduulihakemisto Online -optiota varten
